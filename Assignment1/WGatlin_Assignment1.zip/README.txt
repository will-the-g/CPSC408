Name: William Gatlin
Date: 9/23/24
Assignment: 1 - Relational Algebra
Instructions for Code: N/A
References: In class Notes, Lecture Slides
