Name: William Gatlin
Date: 12/13/2024
Class: CPSC408-04
Assignment: Final Project - Bank App
Files: BankApp.py, BankAppERdiagram.png, BankAppSchema.png, BankDatabase.py, db_ops.py, helper.py, main.py, populateDatabase.sql, kivy_files folder
Video Link of App: https://youtu.be/pLSETqKHlNQ
References: In class Notes, MySQL documentation, lots of kivy documentation, csv documentation, partial documentation. ChatGPT for data generation for populating database. 