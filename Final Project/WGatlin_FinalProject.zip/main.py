import BankApp


def run_bank_app():
    BankApp.BankApp().run()

if __name__ == "__main__":
    run_bank_app()